/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package library.management;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

/**
 *
 * @author Owner
 */
public class DatabaseConnection {
     static Connection conn=null;
     //ALTER TABLE persons MODIFY COLUMN personID INT auto_increment PRIMARY KEY;
    
    public static Connection getObj()
    {
       try
       {
     Class.forName("com.mysql.jdbc.Driver");
           conn=DriverManager.getConnection("jdbc:mysql://localhost/library","root","");
           //JOptionPane.showMessageDialog(null, "Connected to Database");
           return conn;
        }catch(Exception e)
        {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
       
       
    }
}
